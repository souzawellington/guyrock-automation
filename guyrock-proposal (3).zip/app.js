// Global state management
const appState = {
  currentSection: 'hero',
  animationQueue: [],
  isModalOpen: false,
  navigationOpen: false
};

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
});

// Initialize the application
function initializeApp() {
  setupNavigation();
  setupScrollAnimations();
  setupCounterAnimations();
  setupProgressBars();
  setupIntersectionObserver();
  setupSmoothScrolling();
  setupMobileMenu();
  setupFormHandling();
  
  // Add loading animation
  document.body.classList.add('loaded');
  
  console.log('Guyrock Apartments Landing Page Initialized');
}

// Navigation functionality
function setupNavigation() {
  const navbar = document.querySelector('.navbar');
  const navLinks = document.querySelectorAll('.nav-link');
  
  // Navbar background on scroll
  window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
      navbar.style.background = 'rgba(var(--color-surface), 0.98)';
      navbar.style.boxShadow = 'var(--shadow-lg)';
    } else {
      navbar.style.background = 'rgba(var(--color-background), 0.95)';
      navbar.style.boxShadow = 'none';
    }
  });
  
  // Active link highlighting
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href');
      const targetSection = document.querySelector(targetId);
      
      if (targetSection) {
        const offsetTop = targetSection.offsetTop - 80;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
        
        // Close mobile menu if open
        closeMobileMenu();
      }
    });
  });
}

// Mobile menu functionality
function setupMobileMenu() {
  const navToggle = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');
  
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
      toggleMobileMenu();
    });
    
    // Close menu when clicking on links
    const navLinks = navMenu.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        closeMobileMenu();
      });
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
        closeMobileMenu();
      }
    });
  }
}

function toggleMobileMenu() {
  const navToggle = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');
  
  appState.navigationOpen = !appState.navigationOpen;
  
  navToggle.classList.toggle('active');
  navMenu.classList.toggle('active');
  
  // Prevent body scroll when menu is open
  if (appState.navigationOpen) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
}

function closeMobileMenu() {
  const navToggle = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');
  
  if (appState.navigationOpen) {
    appState.navigationOpen = false;
    navToggle.classList.remove('active');
    navMenu.classList.remove('active');
    document.body.style.overflow = '';
  }
}

// Smooth scrolling for all internal links
function setupSmoothScrolling() {
  const links = document.querySelectorAll('a[href^="#"]');
  
  links.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href');
      const targetSection = document.querySelector(targetId);
      
      if (targetSection) {
        const offsetTop = targetSection.offsetTop - 80;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }
    });
  });
}

// Counter animations for statistics
function setupCounterAnimations() {
  const counters = document.querySelectorAll('[data-count]');
  const observerOptions = {
    threshold: 0.5,
    rootMargin: '0px'
  };
  
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        counterObserver.unobserve(entry.target);
      }
    });
  }, observerOptions);
  
  counters.forEach(counter => {
    counterObserver.observe(counter);
  });
}

function animateCounter(element) {
  const target = parseInt(element.dataset.count);
  const duration = 2000;
  const step = target / (duration / 16);
  let current = 0;
  
  const timer = setInterval(() => {
    current += step;
    if (current >= target) {
      element.textContent = target;
      clearInterval(timer);
    } else {
      element.textContent = Math.floor(current);
    }
  }, 16);
}

// Progress bars for roadmap
function setupProgressBars() {
  const progressBars = document.querySelectorAll('.progress-bar');
  const observerOptions = {
    threshold: 0.3,
    rootMargin: '0px'
  };
  
  const progressObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const progressBar = entry.target;
        const progress = progressBar.dataset.progress || '0';
        
        setTimeout(() => {
          progressBar.style.width = progress + '%';
        }, 300);
        
        progressObserver.unobserve(entry.target);
      }
    });
  }, observerOptions);
  
  progressBars.forEach(bar => {
    progressObserver.observe(bar);
  });
}

// Scroll-triggered animations
function setupScrollAnimations() {
  const animatedElements = document.querySelectorAll('.solution-card, .benefit-card, .testimonial-card, .problem-item');
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };
  
  const animationObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        animationObserver.unobserve(entry.target);
      }
    });
  }, observerOptions);
  
  animatedElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    animationObserver.observe(el);
  });
}

// Intersection Observer for section tracking
function setupIntersectionObserver() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  
  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const sectionId = entry.target.id;
        appState.currentSection = sectionId;
        
        // Update active navigation link
        navLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
  }, {
    threshold: 0.3,
    rootMargin: '-80px 0px -50% 0px'
  });
  
  sections.forEach(section => {
    sectionObserver.observe(section);
  });
}

// Timeline animation
function animateTimeline() {
  const timelineSteps = document.querySelectorAll('.timeline-step');
  const timelineLine = document.querySelector('.timeline-line');
  
  if (timelineLine) {
    timelineLine.style.animation = 'drawLine 3s ease-out forwards';
  }
  
  timelineSteps.forEach((step, index) => {
    setTimeout(() => {
      step.style.opacity = '1';
      step.style.transform = 'translateY(0)';
    }, index * 200);
  });
}

// Roadmap interaction
function setupRoadmapInteraction() {
  const roadmapWeeks = document.querySelectorAll('.roadmap-week');
  
  roadmapWeeks.forEach((week, index) => {
    week.addEventListener('click', () => {
      // Remove active class from all weeks
      roadmapWeeks.forEach(w => w.classList.remove('active'));
      
      // Add active class to clicked week and all previous weeks
      for (let i = 0; i <= index; i++) {
        roadmapWeeks[i].classList.add('active');
        const progressBar = roadmapWeeks[i].querySelector('.progress-bar');
        if (progressBar) {
          progressBar.style.width = '100%';
        }
      }
    });
  });
}

// Modal functionality
function openConsultationModal() {
  const modal = document.getElementById('consultationModal');
  if (modal) {
    modal.style.display = 'block';
    appState.isModalOpen = true;
    document.body.style.overflow = 'hidden';
    
    // Focus on first input
    const firstInput = modal.querySelector('input');
    if (firstInput) {
      setTimeout(() => firstInput.focus(), 100);
    }
  }
}

function closeConsultationModal() {
  const modal = document.getElementById('consultationModal');
  if (modal) {
    modal.style.display = 'none';
    appState.isModalOpen = false;
    document.body.style.overflow = '';
  }
}

// Form handling
function setupFormHandling() {
  const modal = document.getElementById('consultationModal');
  
  // Close modal when clicking outside
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeConsultationModal();
      }
    });
  }
  
  // Close modal with Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && appState.isModalOpen) {
      closeConsultationModal();
    }
  });
}

function handleConsultationSubmit(event) {
  event.preventDefault();
  
  const form = event.target;
  const formData = new FormData(form);
  const data = {};
  
  // Collect form data
  for (let [key, value] of formData.entries()) {
    data[key] = value;
  }
  
  // Validate required fields
  const requiredFields = ['name', 'email', 'phone', 'properties'];
  const missingFields = requiredFields.filter(field => !data[field] || data[field].trim() === '');
  
  if (missingFields.length > 0) {
    alert(`Please fill in all required fields: ${missingFields.join(', ')}`);
    return;
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(data.email)) {
    alert('Please enter a valid email address.');
    return;
  }
  
  // Show loading state
  const submitButton = form.querySelector('button[type="submit"]');
  const originalText = submitButton.innerHTML;
  submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
  submitButton.disabled = true;
  
  // Simulate form submission (in real app, this would be an API call)
  setTimeout(() => {
    // Success simulation
    showSuccessMessage();
    form.reset();
    closeConsultationModal();
    
    // Reset button
    submitButton.innerHTML = originalText;
    submitButton.disabled = false;
    
    console.log('Consultation request submitted:', data);
  }, 1500);
}

function showSuccessMessage() {
  // Create success notification
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 100px;
    right: 20px;
    background: var(--color-success);
    color: white;
    padding: 16px 24px;
    border-radius: 12px;
    box-shadow: var(--shadow-lg);
    z-index: 3000;
    transform: translateX(400px);
    transition: transform 0.3s ease;
    max-width: 300px;
  `;
  
  notification.innerHTML = `
    <div style="display: flex; align-items: center; gap: 12px;">
      <i class="fas fa-check-circle" style="font-size: 20px;"></i>
      <div>
        <div style="font-weight: 600; margin-bottom: 4px;">Success!</div>
        <div style="font-size: 14px; opacity: 0.9;">We'll contact you within 24 hours to schedule your consultation.</div>
      </div>
    </div>
  `;
  
  document.body.appendChild(notification);
  
  // Animate in
  setTimeout(() => {
    notification.style.transform = 'translateX(0)';
  }, 100);
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    notification.style.transform = 'translateX(400px)';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 5000);
}

// Property layout interaction
function setupPropertyInteraction() {
  const units = document.querySelectorAll('.unit');
  
  units.forEach(unit => {
    unit.addEventListener('click', () => {
      // Remove active class from all units
      units.forEach(u => u.classList.remove('active'));
      
      // Add active class to clicked unit
      unit.classList.add('active');
      
      // Show unit details (could be expanded)
      const unitName = unit.querySelector('.unit-name').textContent;
      console.log(`Selected unit: ${unitName}`);
    });
  });
}

// Heating logic visualization
function animateHeatingLogic() {
  const heatingSteps = document.querySelectorAll('.heating-step');
  
  heatingSteps.forEach((step, index) => {
    setTimeout(() => {
      step.style.transform = 'scale(1.05)';
      setTimeout(() => {
        step.style.transform = 'scale(1)';
      }, 200);
    }, index * 500);
  });
}

// Utility functions
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function throttle(func, limit) {
  let inThrottle;
  return function() {
    const args = arguments;
    const context = this;
    if (!inThrottle) {
      func.apply(context, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

// Performance optimized scroll handler
const optimizedScrollHandler = throttle(() => {
  const scrolled = window.pageYOffset;
  const rate = scrolled * -0.5;
  
  // Parallax effect for hero background
  const heroBackground = document.querySelector('.hero-background');
  if (heroBackground) {
    heroBackground.style.transform = `translateY(${rate}px)`;
  }
}, 16);

// Add scroll listener for performance-optimized effects
window.addEventListener('scroll', optimizedScrollHandler);

// Keyboard navigation support
document.addEventListener('keydown', (e) => {
  // Navigate sections with arrow keys when not in form
  if (!e.target.matches('input, textarea, select') && !appState.isModalOpen) {
    switch(e.key) {
      case 'ArrowDown':
        e.preventDefault();
        navigateToNextSection();
        break;
      case 'ArrowUp':
        e.preventDefault();
        navigateToPrevSection();
        break;
    }
  }
});

function navigateToNextSection() {
  const sections = document.querySelectorAll('section[id]');
  const currentIndex = Array.from(sections).findIndex(section => 
    section.id === appState.currentSection
  );
  
  if (currentIndex < sections.length - 1) {
    const nextSection = sections[currentIndex + 1];
    nextSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function navigateToPrevSection() {
  const sections = document.querySelectorAll('section[id]');
  const currentIndex = Array.from(sections).findIndex(section => 
    section.id === appState.currentSection
  );
  
  if (currentIndex > 0) {
    const prevSection = sections[currentIndex - 1];
    prevSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

// Analytics and interaction tracking (placeholder)
function trackInteraction(action, element, data = {}) {
  console.log('Track interaction:', {
    action,
    element: element.className || element.tagName,
    timestamp: new Date().toISOString(),
    currentSection: appState.currentSection,
    ...data
  });
  
  // In a real application, this would send data to analytics service
}

// Add interaction tracking to key elements
document.addEventListener('click', (e) => {
  if (e.target.matches('.btn')) {
    trackInteraction('button_click', e.target, {
      buttonText: e.target.textContent.trim()
    });
  }
  
  if (e.target.matches('.solution-card')) {
    trackInteraction('solution_card_click', e.target, {
      solutionName: e.target.querySelector('h3')?.textContent
    });
  }
});

// Error handling and reporting
window.addEventListener('error', (e) => {
  console.error('JavaScript Error:', {
    message: e.message,
    filename: e.filename,
    lineno: e.lineno,
    colno: e.colno,
    error: e.error
  });
  
  // In production, this would report errors to monitoring service
});

// Initialize roadmap interaction after DOM load
document.addEventListener('DOMContentLoaded', () => {
  setupRoadmapInteraction();
  setupPropertyInteraction();
});

// Export functions for global access
window.openConsultationModal = openConsultationModal;
window.closeConsultationModal = closeConsultationModal;
window.handleConsultationSubmit = handleConsultationSubmit;

// Service Worker registration (for future PWA capabilities)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    // Service worker would be registered here in production
    console.log('Service Worker support detected');
  });
}

console.log('Run Your Trip - Guyrock Apartments Application Loaded Successfully');